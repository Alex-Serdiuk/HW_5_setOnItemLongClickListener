package com.example.serverapi.controller;

import com.example.serverapi.Entity.Contact;
import com.example.serverapi.Repository.ContactRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/contacts")
public class ContactController {

    @Autowired
    private ContactRepository repository;

    @GetMapping
    public List<Contact> getAll() {
        return repository.findAll();
    }

    @GetMapping("/{id}")
    public Contact getById(@PathVariable("id") int id) {
        return repository.findById(id).orElse(null);
    }

    @PostMapping
    public Contact add(@RequestBody Contact contact) {
        return repository.save(contact);
    }

    @PutMapping
    public Contact update(@RequestBody Contact contact){
        return repository.save(contact);
    }

    @DeleteMapping("/{id}")
    public void delete(@PathVariable("id") int id) {
        repository.deleteById(id);
    }



}